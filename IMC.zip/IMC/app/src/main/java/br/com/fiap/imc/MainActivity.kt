package br.com.fiap.imc

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //R extend from Object, and it is related to resource folder
        setContentView(R.layout.activity_main)

        calculateBtn.setOnClickListener {
            val nextAct = Intent(this, ResultActivity::class.java)
            nextAct.putExtra("WEIGHT", weightIn.text.toString())
            nextAct.putExtra("HEIGHT", heightIn.text.toString())
            nextAct.putExtra("GENDER", genderSpinner.selectedItem.toString())
            startActivity(nextAct)
        }

        clearBtn.setOnClickListener {
            weightIn.setText("")
            heightIn.setText("")
            genderSpinner.setSelection(0)
        }

    }
}
