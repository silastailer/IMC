package br.com.fiap.imc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_result.*

class ResultActivity : AppCompatActivity() {

    var weight: Double = 0.0
    var height: Double = 0.0
    var gender: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        loadData()
        calculate()
    }

    private fun calculate() {
        val imc = weight / (height * height)
        resultText.text = imc.toFixed(1)

        when {
            imc < 18.5 -> {
                resultFooter.text = getString(R.string.under_weight)
                setImage(R.drawable.fem_abaixo)
            }
            imc < 24.9 -> {
                resultFooter.text = getString(R.string.ideal_weight)
                setImage(R.drawable.fem_ideal)
            }
            imc < 29.9 -> {
                resultFooter.text = getString(R.string.above_weight)
                setImage(R.drawable.fem_sobre)
            }
            imc < 34.9 -> {
                resultFooter.text = getString(R.string.fat_weight)
                setImage(R.drawable.fem_obeso)
            }
            else -> {
                resultFooter.text = getString(R.string.xfat_weight)
                setImage(R.drawable.fem_extremo_obeso)
            }
        }
    }

    fun setImage(resourceId: Int) {
        resultImage.setImageDrawable(
            ContextCompat.getDrawable(this,
                resourceId))
    }


    private fun loadData() {
        this.weight = intent.getStringExtra("WEIGHT").toDouble()
        this.height = intent.getStringExtra("HEIGHT").toDouble()
        this.gender = intent.getStringExtra("GENDER")
    }
}
